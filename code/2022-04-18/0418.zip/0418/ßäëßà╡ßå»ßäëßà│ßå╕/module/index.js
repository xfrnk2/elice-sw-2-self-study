//import

let x = 1;
let y = 2;

console.log(adder(x, y))
