export function dollarToWon(money) {
    var won = money * 1224.5;
    return won;
  }
  