function yuanToWon(money) {
    var won = money * 192.53;
    return won;
  }
  
  function yenToWon(money) {
    var won = money * 9.88;
    return won;
  }
  
  export { yuanToWon, yenToWon };
  