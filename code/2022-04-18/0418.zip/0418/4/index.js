const x = (x, y) => x * y;

document.write(x(5, 5));
