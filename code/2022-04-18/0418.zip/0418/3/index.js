var learn = '자바스크립트';
var year = 3;

var sentence = null;
document.write(sentence);