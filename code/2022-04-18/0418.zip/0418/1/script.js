let x = 2;
const y = 2;

// x = 4;
// y = 4;

document.write(x);
document.write(y);
