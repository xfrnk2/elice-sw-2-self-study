const target = document.getElementsByClassName("attend")[0];
const inputName = document.getElementsByTagName("input")[0];
const attendee = document.getElementById("attendee");

function attend() {
  attendee.textContent = inputName.value;
}

target.addEventListener("click", attend);
