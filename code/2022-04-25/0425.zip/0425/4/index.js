// 지시사항에 따라 코드를 작성합니다.









// 아래의 숫자를 자유롭게 변경해 가며 실행해 보세요.
// 물론 그대로 두어도 됩니다. 채점과는 무관합니다.
const inputA = 1

// 실행 혹은 제출을 위한 코드입니다. 지우거나 수정하지 말아주세요.
module.exports = { inputs: [inputA], func: resolveWhenPositiveNumber }