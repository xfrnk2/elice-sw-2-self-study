// 자유롭게 코드를 작성하여, 예시 화면이 구현되도록 해 보세요.

document.querySelector("input").addEventListener("input", function (e) {
  console.log("입력 내용: ", e.target.value);
});
