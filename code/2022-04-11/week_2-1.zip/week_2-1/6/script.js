var str = "Good morning! Have a nice day."
